import sys, cv2, numpy as np, glob, json
sys.path.insert(0,'/home/claude/tools')
import key_circle as kc
OUT=sys.argv[1]
# ---------- circle (momento revil) ----------
bg=kc.load_bg()
raw=kc.fs[52:243:3]          # 64 frames @20fps
frames=[]
for f in raw:
    im,a=kc.key(f,bg); frames.append((im,a))
ys=[];xs=[]
for im,a in frames:
    yy,xx=np.where(a>40); ys+= [yy.min(),yy.max()]; xs+=[xx.min(),xx.max()]
x0,x1,y0,y1=max(min(xs)-4,0),min(max(xs)+4,695),max(min(ys)-4,0),min(max(ys)+4,383)
x0,x1,y0,y1=int(x0),int(x1),int(y0),int(y1)
sw,sh=int((x1-x0+1)*0.7),int((y1-y0+1)*0.7); cw,ch=sw,sh
print('circle crop',cw,ch)
cols=8; rows=8
sheet=np.zeros((rows*ch,cols*cw,4),np.uint8)
for i,(im,a) in enumerate(frames):
    c=im[y0:y1+1,x0:x1+1]; al=a[y0:y1+1,x0:x1+1]
    rgba=cv2.resize(np.dstack([c,al]),(cw,ch),interpolation=cv2.INTER_AREA); r,cc=divmod(i,cols)
    sheet[r*ch:(r+1)*ch,cc*cw:(cc+1)*cw]=rgba
cv2.imwrite(OUT+'/skel_circle.png',sheet)
json.dump(dict(cols=cols,rows=rows,cw=cw,ch=ch,frames=len(frames),fps=20),open('out/circle.json','w'))
# ---------- solo (momento nutria) ----------
sf=sorted(glob.glob('solo/f_*.png'))
L=54;S0=57;K=0
fr=[cv2.imread(sf[S0+i]).astype(np.float32) for i in range(L)]
for m in range(K):
    i=L-K+m; w=(m+1)/(K+1)
    fr[i]=(1-w)*fr[i]+w*cv2.imread(sf[S0+i-L]).astype(np.float32)
X0,X1,Y0,Y1=190,540,120,712
def keyed(img):
    g=img.max(axis=2)
    a=np.clip((g-6)/38.0,0,1)
    a=cv2.GaussianBlur(a,(3,3),0)
    col=np.where(a[...,None]>0.02,np.clip(img/np.maximum(a[...,None],0.35),0,255),0)
    return np.dstack([col,a*255]).astype(np.uint8)
cw2,ch2=(X1-X0),(Y1-Y0)
sc2=0.6; w2,h2=int(cw2*sc2),int(ch2*sc2)
cols2=9; rows2=6
sheet2=np.zeros((rows2*h2,cols2*w2,4),np.uint8)
for i,img in enumerate(fr):
    k=keyed(img)[Y0:Y1,X0:X1]; k=cv2.resize(k,(w2,h2),interpolation=cv2.INTER_AREA)
    r,c=divmod(i,cols2); sheet2[r*h2:(r+1)*h2,c*w2:(c+1)*w2]=k
cv2.imwrite(OUT+'/skel_solo.png',sheet2)
json.dump(dict(cols=cols2,rows=rows2,cw=w2,ch=h2,frames=L,fps=30),open('out/solo.json','w'))
print('solo cell',w2,h2)
