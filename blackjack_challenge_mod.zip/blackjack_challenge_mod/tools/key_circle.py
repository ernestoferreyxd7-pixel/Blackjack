import cv2, numpy as np, glob
K=lambda n: cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(n,n))
fs=sorted(glob.glob('circ/f_*.png'))
def load_bg():
    st=np.stack([cv2.GaussianBlur(cv2.imread(f,0),(5,5),0) for f in fs[::3]])
    return np.median(st,axis=0).astype(np.float32)
def key(path,bg):
    im=cv2.imread(path); g=cv2.GaussianBlur(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),(5,5),0).astype(np.float32)
    d=np.abs(g-bg)
    gi=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    M=(((d>40))|((gi>184)&(d>20))).astype(np.uint8)
    M=cv2.morphologyEx(M,cv2.MORPH_OPEN,K(3))
    M=cv2.morphologyEx(M,cv2.MORPH_CLOSE,K(7))
    M255=M*255
    ff=M255.copy(); h,w=ff.shape; m=np.zeros((h+2,w+2),np.uint8)
    cv2.floodFill(ff,m,(0,0),255)
    holes=cv2.bitwise_not(ff)
    nh,lh,sh,_=cv2.connectedComponentsWithStats(holes,8)
    for i in range(1,nh):
        if sh[i,cv2.CC_STAT_AREA]<420: M255[lh==i]=255
    n,lab,st,_=cv2.connectedComponentsWithStats(M255,8)
    keep=np.zeros_like(M255)
    for i in range(1,n):
        if st[i,cv2.CC_STAT_AREA]>350: keep[lab==i]=255
    keep=cv2.dilate(keep,K(3))
    return im,cv2.GaussianBlur(keep,(3,3),0)
if __name__=='__main__':
    bg=load_bg(); cv2.imwrite('out/circ_bg.png',bg.astype(np.uint8))
    tiles=[]
    for idx in (20,100,180,260,340,390):
        im,a=key(fs[idx],bg); bgc=np.full_like(im,(200,0,200)); al=(a[...,None]/255.0)
        tiles.append((im*al+bgc*(1-al)).astype(np.uint8))
    cv2.imwrite('out/circ_test.png',np.vstack([np.hstack(tiles[:2]),np.hstack(tiles[2:4]),np.hstack(tiles[4:])]))
