import sys, os, subprocess, numpy as np
from scipy import signal
from scipy.io import wavfile
OUT=sys.argv[1]; TMP=sys.argv[2]; os.makedirs(OUT,exist_ok=True); os.makedirs(TMP,exist_ok=True)
SR=44100; rng=np.random.RandomState(7)
T=lambda d: np.arange(int(d*SR))/SR
def norm(x,peak=0.9):
    m=np.max(np.abs(x)); return x/m*peak if m>0 else x
def save(name,x,stereo=False):
    x=np.clip(x,-1,1)
    if x.ndim==1 and stereo: x=np.stack([x,x],1)
    wavfile.write(f'{TMP}/{name}.wav',SR,(x*32767).astype(np.int16))
    subprocess.run(['ffmpeg','-v','error','-y','-i',f'{TMP}/{name}.wav','-c:a','libvorbis','-q:a','4',f'{OUT}/{name}.ogg'],check=True)
def bp(x,lo,hi,o=3): return signal.sosfilt(signal.butter(o,[lo,hi],'band',fs=SR,output='sos'),x)
def lp(x,f,o=3): return signal.sosfilt(signal.butter(o,f,'low',fs=SR,output='sos'),x)
def hp(x,f,o=3): return signal.sosfilt(signal.butter(o,f,'high',fs=SR,output='sos'),x)
def noise(d): return rng.randn(int(d*SR))
def env_exp(n,decay): return np.exp(-np.arange(n)/SR*decay)
def place(buf,x,t0):
    i=int(t0*SR); j=min(len(buf),i+len(x))
    if i<len(buf): buf[i:j]+=x[:j-i]
def tone(f,d,kind='sine',vib=0,vf=5.5):
    t=T(d); ph=2*np.pi*f*t+ (vib*np.sin(2*np.pi*vf*t) if vib else 0)
    if kind=='sine': return np.sin(ph)
    if kind=='saw': return signal.sawtooth(ph)
    if kind=='sq': return signal.square(ph)
    if kind=='tri': return signal.sawtooth(ph,0.5)
    if kind=='bell': return np.sin(ph)+0.5*np.sin(2.76*ph)+0.25*np.sin(5.4*ph)
def mallet(f,d=0.35):
    t=T(d); e=np.exp(-t*9); return (np.sin(2*np.pi*f*t)+0.35*np.sin(2*np.pi*f*3.9*t)*np.exp(-t*22))*e
def pan(x,p): # p -1..1
    l=np.sqrt((1-p)/2); r=np.sqrt((1+p)/2); return np.stack([x*l,x*r],1)

# ---------- effects ----------
def click(f=3000,d=0.02,g=1.0):
    n=noise(d+0.02); n=bp(n,f*0.6,f*1.5); return n*env_exp(len(n),380)*g
# shuffle: riffle clicks
b=np.zeros(int(1.7*SR)); t=0.02
while t<1.55:
    place(b,click(rng.uniform(2200,5200),0.02,rng.uniform(.4,1)),t); t+=rng.uniform(0.012,0.03)*(1+ (t/1.55)*0.2)
place(b,bp(noise(0.5),400,2500)*np.exp(-T(0.5)*9)*0.5,1.5)
save('shuffle',norm(b*0.9))
# deal: swish
d=noise(0.3); sw=np.linspace(1200,5200,len(d)); 
sig=np.zeros(len(d)); ph=0
f1=bp(d,900,6000)*np.sin(np.pi*np.linspace(0,1,len(d)))**1.5
f1[int(0.12*SR):]+=0
tap=bp(noise(0.06),150,900)*env_exp(int(.06*SR),90)
b=np.zeros(int(.35*SR)); place(b,f1*0.8,0); place(b,tap*1.5,0.14)
save('deal',norm(b))
# flip
n=noise(0.12); fl=bp(n,2500,7000)*env_exp(len(n),70)
save('flip',norm(fl*(1+tone(30,.12)*0)))
# chip clink
b=np.zeros(int(.6*SR))
for k,(t0,fb) in enumerate([(0,1),(0.07,1.18),(0.15,.92)]):
    t=T(.35); x=sum(np.sin(2*np.pi*f*fb*t)*a for f,a in [(2900,1),(4380,.7),(6100,.4),(1850,.5)])*np.exp(-t*(26+k*6))
    place(b,x*(0.8-k*.15),t0)
save('chip',norm(b))
# blackjack/21 jingle
b=np.zeros(int(2.6*SR))
for i,f in enumerate([523.25,659.25,783.99,1046.5,1318.5,1568]):
    place(b,tone(f,1.0,'bell')*np.exp(-T(1.0)*3.2)*0.35,0.09*i)
for f in (523.25,659.25,783.99,1046.5):
    place(b,tone(f,1.6,'bell')*np.exp(-T(1.6)*2.2)*0.25,0.62)
for k in range(40): place(b,click(rng.uniform(5000,9000),0.015,0.35)*1.0,0.65+rng.uniform(0,1.2))
save('blackjack',norm(b))
# bust: wah wah wah waaah
b=np.zeros(int(2.4*SR))
notes=[(311.1,.35),(293.7,.35),(277.2,.35),(261.6,.9)]
t0=0
for i,(f,d) in enumerate(notes):
    n=tone(f,d,'saw',vib=(0 if i<3 else 2.2),vf=6)*np.minimum(1,T(d)*30)*np.minimum(1,(d-T(d))*12)
    w=0.5+0.5*np.sin(2*np.pi*(3 if i<3 else 5)*T(d))
    n=lp(n,500)*(1-w)+lp(n,2400)*w; place(b,n*0.6,t0); t0+=d
save('bust',norm(b*1.0))
# neutral result
b=np.zeros(int(1.4*SR))
for f,a in [(392,1),(523.25,.8),(659.25,.7)]: place(b,tone(f,1.3,'bell')*np.exp(-T(1.3)*3)*a*.35,0)
place(b,click(4200,0.02,.6),0)
save('result',norm(b))
# counter tick
b=tone(1700,.05,'sq')*env_exp(int(.05*SR),90); save('tick',norm(b*0.5))
# win-ish card slam / hit thud for 7s
b=np.zeros(int(.5*SR)); place(b,lp(noise(.4),600)*env_exp(int(.4*SR),14)*1.3,0); place(b,tone(70,.4)*env_exp(int(.4*SR),10),0); save('thud',norm(b))

# ---------- nutria music (skeleton bop) ~ 11 s ----------
BPM=126; S16=60/BPM/4; steps=80; total=steps*S16+1.6
buf=np.zeros((int(total*SR),2))
mid=lambda m: 440*2**((m-69)/12)
def put(x,t0,p=0.0,g=1.0): 
    i=int(t0*SR); y=pan(x,p)*g; j=min(len(buf),i+len(y)); buf[i:j]+=y[:j-i]
mel={0:[(0,69),(3,72),(6,76),(8,74),(10,72),(12,71)],1:[(0,72),(3,76),(6,81),(8,80),(10,76),(12,77)]}
for bar in range(5):
    b0=bar*16
    pat=mel[bar%2]
    if bar==4: pat=[(0,81),(4,76),(8,69)]
    for st,m in pat:
        put(mallet(mid(m),.45),(b0+st)*S16,0.2,0.55)
        if bar>=2: put(mallet(mid(m+12),.3),(b0+st)*S16+S16*.5,-0.3,0.22)
    # bass
    roots=[45,52,45,52] if bar%2==0 else [41,48,40,47]
    if bar==4: roots=[45,45,45,45]
    for k,m in enumerate(roots):
        put(tone(mid(m),S16*3.6,'tri')*np.minimum(1,T(S16*3.6)*60)*np.exp(-T(S16*3.6)*4),(b0+k*4)*S16,0,0.5)
    # drums
    for st in range(16):
        tt=(b0+st)*S16
        if st in (0,8) or (bar>=1 and st==11):
            kk=np.sin(2*np.pi*np.cumsum(np.linspace(130,45,int(.2*SR)))/SR)*env_exp(int(.2*SR),22); put(kk,tt,0,0.9)
        if st in (4,12):
            sn=bp(noise(.2),1200,7000)*env_exp(int(.2*SR),24); sn[:int(.15*SR)]+=tone(190,.15)[:int(.15*SR)]*env_exp(int(.15*SR),30)*.5; put(sn,tt,0.1,0.55)
        if st%2==0:
            put(hp(noise(.05),7000)*env_exp(int(.05*SR),110),tt,-0.2,0.18 if st%4 else 0.1)
        if st%4==2:   # bone rattle
            r=np.zeros(int(.12*SR))
            for q in range(3): place(r,bp(noise(.03),1400,3800)*env_exp(int(.03*SR),160),q*.035)
            put(r,tt,rng.uniform(-.7,.7),0.5)
# final hit
fh=tt0=(steps)*S16
for m in (57,60,64,69): put(mallet(mid(m),1.2)*1.0,fh,0,0.4)
put(np.sin(2*np.pi*np.cumsum(np.linspace(160,40,int(.3*SR)))/SR)*env_exp(int(.3*SR),12),fh,0,1.0)
buf[:,0]=lp(buf[:,0],9000); buf[:,1]=lp(buf[:,1],9000)
save('nutria_music',norm(buf,0.9))
print('nutria seconds',round(total,2))

# ---------- revil tension loop (16 s, seamless) ----------
L=16.0; N=int(L*SR)+int(2*SR); t=np.arange(N)/SR
def per(f): return round(f*L)/L   # force periodic over L
drone=np.zeros(N)
for f,a in [(55,1),(58.25,.9),(77.75,.7),(110.0,.3),(116.5,.25)]:
    drone+=signal.sawtooth(2*np.pi*per(f)*t+rng.uniform(0,6))*a
lfo=0.5+0.5*np.sin(2*np.pi*(2/L)*t)
dr=lp(drone,280); dr2=lp(drone,900)
drone=dr*(0.7)+dr2*0.5*lfo
drone*=(0.65+0.35*np.sin(2*np.pi*(4/L)*t+1))
L_=np.zeros(N); R_=np.zeros(N)
# heartbeat period 0.8 s (20 per loop)
hb=np.zeros(N)
for k in range(int(L/0.8)+4):
    t0=k*0.8
    for off,g in ((0,1.0),(0.19,0.7)):
        d_=0.3; th=T(d_); x=np.sin(2*np.pi*np.cumsum(np.linspace(75,42,len(th)))/SR)*np.exp(-th*16)*g
        place(hb,x,t0+off)
hb=lp(hb,160)*2.2
# shrieks
shr=np.zeros((N,2))
for t0,f0,f1,d_,p in [(2.6,2100,2900,2.2,-.6),(6.9,1500,2250,2.8,.6),(10.4,3100,2300,2.0,-.3),(13.1,1900,3300,2.4,.5)]:
    th=T(d_); fr=np.linspace(f0,f1,len(th))+30*np.sin(2*np.pi*6.5*th)
    x=np.sin(2*np.pi*np.cumsum(fr)/SR)+0.4*np.sin(2*np.pi*np.cumsum(fr*2.01)/SR)
    x*=np.sin(np.pi*th/d_)**2*0.16
    y=pan(x,p); i=int(t0*SR); shr[i:i+len(y)]+=y
# whispers
wh=np.zeros((N,2))
for t0 in (1.4,5.2,8.8,12.2,14.6):
    d_=1.4; th=T(d_); n=noise(d_)
    f1=bp(n,500,1100)+bp(n,1700,2700)*0.6+hp(n,4500)*0.5
    syl=(0.5+0.5*np.sin(2*np.pi*(4.5+rng.uniform(0,2))*th+rng.uniform(0,6)))**2
    x=f1*syl*np.sin(np.pi*th/d_)*0.35
    y=pan(x,rng.choice([-0.9,0.9])); i=int(t0*SR); wh[i:i+len(y)]+=y
# reverse-cymbal swells ending on loop boundary + boom
sw=np.zeros(N)
for t0,d_ in ((6.8,1.2),(14.0,2.0)):
    th=T(d_); n=hp(noise(d_),2500)*(th/d_)**3*0.45; place(sw,n,t0)
boom=np.zeros(N)
for t0 in (0.0,8.0):
    th=T(1.8); x=(np.sin(2*np.pi*np.cumsum(np.linspace(90,32,len(th)))/SR)*np.exp(-th*2.3)+lp(noise(1.8),200)*np.exp(-th*4)*.7)
    place(boom,x*1.2,t0)
mix=np.stack([drone*0.55+hb*0.55+sw*0.5+boom*0.8]*2,1)+shr+wh
# make loop seamless: crossfade tail (the extra 2s) over the head
body=mix[:int(L*SR)].copy(); tail=mix[int(L*SR):int(L*SR)+int(2*SR)]
cf=int(2*SR); w=np.linspace(0,1,cf)[:,None]
body[:cf]=body[:cf]*w+tail*(1-w)
save('revil_tension',norm(body,0.9))
# revil sting at the very end
d_=3.5; th=T(d_); b=np.zeros((int(d_*SR),2))
x=np.sin(2*np.pi*np.cumsum(np.linspace(110,28,len(th)))/SR)*np.exp(-th*1.5)*1.2+lp(noise(d_),300)*np.exp(-th*3)
scr=sum(np.sin(2*np.pi*np.cumsum(np.linspace(f,f*1.5,len(th)))/SR) for f in (1800,1900,2650,3100))*np.exp(-th*4)*0.2
b[:,0]=x+scr; b[:,1]=x+scr*0.9
save('revil_sting',norm(b,0.95))
print('done')
