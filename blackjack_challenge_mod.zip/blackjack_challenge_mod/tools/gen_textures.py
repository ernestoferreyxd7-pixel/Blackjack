import sys, math, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter
OUT=sys.argv[1]
SS=2
SERIF='/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'
SANS='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
SYM='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
F=lambda p,s: ImageFont.truetype(p,int(s*SS))
CW,CH=160,224
SUITS=['♠','♥','♦','♣']   # row order: spades, hearts, diamonds, clubs
RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K']
RED=(196,24,38,255); BLK=(24,24,30,255)

def rrect(d,box,r,fill=None,outline=None,width=1):
    d.rounded_rectangle([v*SS for v in box],radius=r*SS,fill=fill,outline=outline,width=width*SS)

def suit_glyph(d,suit,cx,cy,size,col,flip=False):
    f=F(SYM,size); ch=SUITS[suit]
    bb=d.textbbox((0,0),ch,font=f); w=bb[2]-bb[0]; h=bb[3]-bb[1]
    if not flip:
        d.text((cx*SS-w/2-bb[0],cy*SS-h/2-bb[1]),ch,font=f,fill=col)
    else:
        tmp=Image.new('RGBA',(int(w+8),int(h+8)),(0,0,0,0)); td=ImageDraw.Draw(tmp)
        td.text((4-bb[0],4-bb[1]),ch,font=f,fill=col); tmp=tmp.rotate(180)
        d._image.alpha_composite(tmp,(int(cx*SS-tmp.width/2),int(cy*SS-tmp.height/2)))

PIPS={ # (x,y) in 0..1 normalized inside pip area
 1:[(.5,.5)],2:[(.5,0),(.5,1)],3:[(.5,0),(.5,.5),(.5,1)],
 4:[(0,0),(1,0),(0,1),(1,1)],5:[(0,0),(1,0),(.5,.5),(0,1),(1,1)],
 6:[(0,0),(1,0),(0,.5),(1,.5),(0,1),(1,1)],
 7:[(0,0),(1,0),(.5,.25),(0,.5),(1,.5),(0,1),(1,1)],
 8:[(0,0),(1,0),(.5,.25),(0,.5),(1,.5),(.5,.75),(0,1),(1,1)],
 9:[(0,0),(1,0),(0,.33),(1,.33),(.5,.5),(0,.66),(1,.66),(0,1),(1,1)],
 10:[(0,0),(1,0),(.5,.17),(0,.33),(1,.33),(0,.66),(1,.66),(.5,.83),(0,1),(1,1)]}

def make_card(rank,suit):
    im=Image.new('RGBA',(CW*SS,CH*SS),(0,0,0,0)); d=ImageDraw.Draw(im)
    col=RED if suit in (1,2) else BLK
    rrect(d,(1,1,CW-2,CH-2),14,fill=(250,247,238,255),outline=(60,60,70,255),width=2)
    rrect(d,(6,6,CW-7,CH-7),10,outline=(0,0,0,28),width=1)
    # corner indices
    rf=F(SERIF,34 if rank!=9 else 28)
    t=RANKS[rank]; bb=d.textbbox((0,0),t,font=rf); w=bb[2]-bb[0]
    d.text((22*SS-w/2-bb[0],10*SS-bb[1]),t,font=rf,fill=col)
    suit_glyph(d,suit,22,58,26,col)
    # bottom (rotated)
    tmp=Image.new('RGBA',(60*SS,80*SS),(0,0,0,0)); td=ImageDraw.Draw(tmp)
    td.text((30*SS-w/2-bb[0],4*SS-bb[1]),t,font=rf,fill=col)
    suit_glyph(td,suit,30,52,26,col)
    tmp=tmp.rotate(180); im.alpha_composite(tmp,((CW-52)*SS,(CH-84)*SS+0))
    # body
    n=rank+1
    if n==1:
        suit_glyph(d,suit,CW/2,CH/2,96,col)
    elif n<=10:
        x0,x1,y0,y1=50,CW-50,46,CH-46
        for (px,py) in PIPS[n]:
            x=x0+(x1-x0)*px; y=y0+(y1-y0)*py
            suit_glyph(d,suit,x,y,34,col,flip=(py>.5 and n!=1))
    else:
        rrect(d,(40,38,CW-41,CH-39),8,fill=(255,243,205,255),outline=col,width=2)
        rrect(d,(46,44,CW-47,CH-45),6,outline=(190,150,60,255),width=2)
        letter=RANKS[rank]; f=F(SERIF,92); bb2=d.textbbox((0,0),letter,font=f)
        d.text((CW*SS/2-(bb2[2]-bb2[0])/2-bb2[0],CH*SS/2-(bb2[3]-bb2[1])/2-bb2[1]-6*SS),letter,font=f,fill=col)
        suit_glyph(d,suit,CW/2,58,30,col); suit_glyph(d,suit,CW/2,CH-58,30,col,flip=True)
    return im.resize((CW,CH),Image.LANCZOS)

sheet=Image.new('RGBA',(CW*13,CH*4),(0,0,0,0))
for s in range(4):
    for r in range(13):
        sheet.alpha_composite(make_card(r,s),(r*CW,s*CH))
sheet.save(OUT+'/cards.png',optimize=True)

# ---- card back
def make_back(tint=(120,18,34)):
    im=Image.new('RGBA',(CW*SS,CH*SS),(0,0,0,0)); d=ImageDraw.Draw(im)
    rrect(d,(1,1,CW-2,CH-2),14,fill=(250,247,238,255),outline=(60,60,70,255),width=2)
    rrect(d,(9,9,CW-10,CH-10),8,fill=tint+(255,))
    # diamond lattice
    lat=Image.new('RGBA',im.size,(0,0,0,0)); ld=ImageDraw.Draw(lat)
    step=18*SS
    for i in range(-20,40):
        ld.line([(i*step,0),(i*step+CH*SS,CH*SS)],fill=(255,255,255,70),width=SS*2)
        ld.line([(i*step,CH*SS),(i*step+CH*SS,0)],fill=(255,255,255,70),width=SS*2)
    mask=Image.new('L',im.size,0); ImageDraw.Draw(mask).rounded_rectangle([9*SS,9*SS,(CW-10)*SS,(CH-10)*SS],radius=8*SS,fill=255)
    lat.putalpha(Image.eval(lat.split()[3],lambda v:v).point(lambda v:v)); lat2=Image.new('RGBA',im.size,(0,0,0,0)); lat2.paste(lat,(0,0),mask); im.alpha_composite(lat2)
    rrect(d,(15,15,CW-16,CH-16),5,outline=(240,200,110,255),width=2)
    # center medallion
    cx,cy=CW*SS/2,CH*SS/2
    d.ellipse([cx-34*SS,cy-34*SS,cx+34*SS,cy+34*SS],fill=(20,8,12,255),outline=(240,200,110,255),width=3*SS)
    f=F(SYM,48); bb=d.textbbox((0,0),'♠',font=f)
    d.text((cx-(bb[2]-bb[0])/2-bb[0],cy-(bb[3]-bb[1])/2-bb[1]),'♠',font=f,fill=(240,200,110,255))
    return im.resize((CW,CH),Image.LANCZOS)
make_back().save(OUT+'/card_back.png',optimize=True)
make_back((20,20,24)).save(OUT+'/card_back_black.png',optimize=True)

# ---- table 1280x720
TW,TH=1280,720
def table():
    S=2; W,H=TW*S,TH*S
    im=Image.new('RGBA',(W,H),(0,0,0,0))
    def shape(inset):
        m=Image.new('L',(W,H),0); d=ImageDraw.Draw(m)
        i=inset*S
        d.rectangle([i,40*S+i,W-i,380*S],fill=255)
        d.ellipse([i,(380-345)*S+i,W-i,(380+345)*S-i],fill=255)
        d.rectangle([0,0,W,40*S+i-1],fill=0)
        return m
    # wood rim
    wood=Image.new('RGBA',(W,H),(0,0,0,0)); wd=ImageDraw.Draw(wood)
    rnd=random.Random(3)
    for y in range(H):
        v=int(58+14*math.sin(y/9.0)+rnd.randint(-5,5)); wd.line([(0,y),(W,y)],fill=(v+34,v+8,v-18,255))
    im.paste(wood,(0,0),shape(0))
    # gold ring
    gold=Image.new('RGBA',(W,H),(214,170,70,255)); im.paste(gold,(0,0),shape(22))
    # felt with radial light
    felt=Image.new('RGBA',(W,H),(0,0,0,0)); fp=felt.load()
    import numpy as np
    yy,xx=np.mgrid[0:H,0:W]; dist=np.sqrt(((xx-W/2)/(W*0.6))**2+((yy-H*0.42)/(H*0.62))**2)
    g=np.clip(1.0-dist*0.65,0.28,1)
    arr=np.zeros((H,W,4),np.uint8); arr[...,0]=(10+30*g).astype(np.uint8); arr[...,1]=(70+85*g).astype(np.uint8); arr[...,2]=(42+40*g).astype(np.uint8); arr[...,3]=255
    noise=(np.random.RandomState(1).randn(H,W)*3).astype(np.int16)
    for c in range(3): arr[...,c]=np.clip(arr[...,c].astype(np.int16)+noise,0,255)
    felt=Image.fromarray(arr); im.paste(felt,(0,0),shape(27))
    d=ImageDraw.Draw(im)
    # inner gold line
    m1=shape(62); m2=shape(66)
    line=Image.new('RGBA',(W,H),(236,200,100,255)); 
    ring=Image.composite(line,Image.new('RGBA',(W,H),(0,0,0,0)),Image.fromarray((np.array(m1)>0).astype(np.uint8)*255)); 
    inner=Image.fromarray(((np.array(m1)>0)&~(np.array(m2)>0)).astype(np.uint8)*255)
    im.paste(line,(0,0),inner)
    # arc text (apex-centred, proper glyph widths)
    def arc_text(txt,apexY,r,font,col,track=0):
        cx0=W/2; cy0=apexY*S+r
        ws=[font.getlength(ch)+track*S for ch in txt]; total=sum(ws)
        ang=-math.pi/2-(total/r)/2; 
        for ch,w in zip(txt,ws):
            a=ang+(w/r)/2
            x=cx0+r*math.cos(a); y=cy0+r*math.sin(a)
            t=Image.new('RGBA',(400,400),(0,0,0,0)); td=ImageDraw.Draw(t)
            td.text((200,200),ch,font=font,fill=col,anchor='mm')
            t=t.rotate(-(math.degrees(a)+90),resample=Image.BICUBIC)
            im.alpha_composite(t,(int(x-200),int(y-200)))
            ang+=w/r
    gold=(238,206,110,255)
    arc_text('BLACKJACK',305,1100*S,ImageFont.truetype(SERIF,64*S),gold,track=10)
    arc_text('PAGA 3 A 2',356,1050*S,ImageFont.truetype(SANS,28*S),(235,245,235,255),track=6)
    arc_text('LA BANCA SE PLANTA EN 17',390,1020*S,ImageFont.truetype(SANS,19*S),(205,230,205,230),track=3)
    # betting circle (left side)
    cx,cy,r=250*S,520*S,50*S
    d.ellipse([cx-r,cy-r,cx+r,cy+r],outline=(236,200,100,255),width=4*S)
    d.ellipse([cx-r+12*S,cy-r+12*S,cx+r-12*S,cy+r-12*S],outline=(236,200,100,130),width=2*S)
    # dealer label
    f2=ImageFont.truetype(SANS,24*S)
    d.text((W/2,240*S),'BANCA',font=f2,fill=(220,240,220,150),anchor='mm')
    d.text((W/2,424*S),'JUGADOR',font=f2,fill=(220,240,220,150),anchor='mm')
    return im.resize((TW,TH),Image.LANCZOS)
table().save(OUT+'/table.png',optimize=True)

# ---- chips (5 colors in a row, 96px each)
def chip(col):
    S=3; N=96*S; im=Image.new('RGBA',(N,N),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.ellipse([4*S,6*S,N-4*S,N-2*S],fill=(0,0,0,90))
    d.ellipse([2*S,2*S,N-2*S,N-6*S],fill=col+(255,),outline=(20,20,20,255),width=2*S)
    c=N/2; cy=(N-4*S)/2
    for k in range(8):
        a=k*math.pi/4
        x=c+math.cos(a)*38*S; y=cy+math.sin(a)*38*S
        d.ellipse([x-8*S,y-8*S,x+8*S,y+8*S],fill=(245,245,240,255))
    d.ellipse([c-30*S,cy-30*S,c+30*S,cy+30*S],fill=col+(255,),outline=(245,245,240,255),width=3*S)
    d.ellipse([c-21*S,cy-21*S,c+21*S,cy+21*S],outline=(245,245,240,200),width=2*S)
    return im.resize((96,96),Image.LANCZOS)
cols=[(200,30,40),(30,90,200),(30,150,70),(30,30,34),(130,50,170)]
chips=Image.new('RGBA',(96*5,96),(0,0,0,0))
for i,c in enumerate(cols): chips.alpha_composite(chip(c),(i*96,0))
chips.save(OUT+'/chips.png',optimize=True)

# ---- shoe 256x170
def shoe():
    S=2; W,H=256*S,170*S; im=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.polygon([(10*S,150*S),(246*S,150*S),(246*S,60*S),(150*S,20*S),(10*S,60*S)],fill=(40,24,16,255),outline=(214,170,70,255))
    d.polygon([(26*S,142*S),(238*S,142*S),(238*S,66*S),(148*S,30*S),(26*S,66*S)],fill=(70,42,26,255))
    # card stack peeking
    for i in range(6):
        d.rounded_rectangle([(30+i*1)*S,(52-i*2)*S,(190)*S,(68-i*2)*S],radius=3*S,fill=(250,247,238,255),outline=(90,90,90,255))
    d.rectangle([20*S,100*S,236*S,112*S],fill=(214,170,70,255))
    return im.resize((256,170),Image.LANCZOS)
shoe().save(OUT+'/shoe.png',optimize=True)
# ---- soft glow
g=Image.new('RGBA',(128,128),(0,0,0,0)); import numpy as np
yy,xx=np.mgrid[0:128,0:128]; r=np.sqrt((xx-64)**2+(yy-64)**2)/64
a=np.clip(1-r,0,1)**2; arr=np.zeros((128,128,4),np.uint8); arr[...,:3]=255; arr[...,3]=(a*255).astype(np.uint8)
Image.fromarray(arr).save(OUT+'/glow.png')
print('ok')
