# Blackjack Challenge (Fabric 1.21.1)

La "ruleta de retos" pero en **Blackjack**. Un overlay animado (no bloquea el juego) con mesa de casino:
las cartas se reparten **una por una** (vuelo desde el zapato, giro, suspenso, totales que suben), sonido de
barajar, repartir, voltear, fichas y sonido final de blackjack / bust.

## Qué pasa en cada caso
| Tipo | Mano | Final |
|---|---|---|
| NORMAL | mano aleatoria distinta cada vez (nunca 7-7-7 ni 6-6-6) | cinta con el reto |
| NUTRIA | 7 ♠ · 7 ♥ · 7 ♦ = 21, la 3ª carta con suspenso | la mesa cae y **baila un esqueleto** + música |
| REVIL | 6-6-6-6 = 24, **te pasaste**; la banca tiene blackjack | la mesa cae y **esqueletos bailando en círculo**, cada vez más perturbador |

Momento Revil: la música de tensión es un **loop que no se corta** hasta que termina TODA la animación
(sube de volumen y tono; baja solo en los últimos 0.8 s). Glitch, estelas rojas, latido, parpadeos de apagón,
más esqueletos van apareciendo y al final se acercan a cámara. Solo se ven los esqueletos (fondo quitado).

## Compilar
Necesitas JDK 21 y Gradle 8.8+ (o abre la carpeta en IntelliJ).
```
gradle wrapper --gradle-version 8.10.2     # una sola vez
./gradlew build                            # el .jar queda en build/libs/
```
Mete el jar en `mods/` junto con **Fabric API** (1.21.1). Sirve en servidor y en singleplayer;
el cliente necesita el mod para ver la animación.

## Uso
- `/blackjack` – una mano para ti (op nivel 2)
- `/blackjack @a` – para todos · `/blackjack <jugadores> nutria|revil|<id>` – fuerza un reto
- `/blackjack list` · `/blackjack reload`

## Tus retos
`config/blackjackchallenge.json` (se crea solo). Cada reto: `id`, `name`, `description`, `weight` (probabilidad),
`type` (NORMAL / NUTRIA / REVIL) y `commands` (`%player%` = jugador). También: `nutriaSeconds`, `revilSeconds`,
`revilVignette` (oscurece bordes en Revil; apagado por defecto).
El reto se aplica **al terminar la animación**.

## Assets
Se generaron con los scripts de `tools/` (esqueletos recortados de tus videos, cartas/mesa con PIL, sonidos sintetizados).
