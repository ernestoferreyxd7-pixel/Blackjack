package com.blackjackchallenge.server;

import com.blackjackchallenge.BlackjackMod;
import com.blackjackchallenge.game.ChallengeConfig;
import com.blackjackchallenge.game.Script;
import com.blackjackchallenge.game.ScriptFactory;
import com.blackjackchallenge.game.Timeline;
import com.blackjackchallenge.net.StartPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Manos en curso. El reto se APLICA cuando el cliente avisa que termino la animacion (o por timeout). */
public final class PendingRuns {
    private PendingRuns() {}

    private record Pending(String token, ChallengeConfig.Entry entry, long deadlineTick) {}
    private static final Map<UUID, Pending> PENDING = new HashMap<>();
    private static final Random RNG = new Random();

    /** Lanza una mano para el jugador. entry == null -> al azar segun los pesos. */
    public static void start(ServerPlayerEntity player, ChallengeConfig.Entry forced) {
        ChallengeConfig cfg = ChallengeConfig.get();
        ChallengeConfig.Entry entry = forced != null ? forced : cfg.pick(RNG);
        MinecraftServer server = player.getServer();
        if (server == null) return;

        // Cliente sin el mod: no hay animacion, aplicamos directo.
        if (!ServerPlayNetworking.canSend(player, StartPayload.ID)) {
            server.sendMessage(Text.literal("[Blackjack] " + player.getName().getString() + " no tiene el mod; reto directo."));
            execute(player, entry);
            return;
        }
        Script script = ScriptFactory.create(entry, cfg, RNG);
        Timeline tl = new Timeline(script);
        long ticks = (long) Math.ceil(tl.total * 20.0) + 200;           // +10 s de margen
        PENDING.put(player.getUuid(), new Pending(script.token(), entry, server.getTicks() + ticks));
        ServerPlayNetworking.send(player, new StartPayload(script.encode()));
    }

    public static void complete(ServerPlayerEntity player, String token) {
        Pending p = PENDING.get(player.getUuid());
        if (p == null || !p.token().equals(token)) return;
        PENDING.remove(player.getUuid());
        execute(player, p.entry());
    }

    public static void tick(MinecraftServer server) {
        if (PENDING.isEmpty()) return;
        long now = server.getTicks();
        Iterator<Map.Entry<UUID, Pending>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Pending> en = it.next();
            if (now < en.getValue().deadlineTick()) continue;
            it.remove();
            ServerPlayerEntity pl = server.getPlayerManager().getPlayer(en.getKey());
            if (pl != null) execute(pl, en.getValue().entry());
        }
    }

    public static void forget(UUID id) { PENDING.remove(id); }

    public static void execute(ServerPlayerEntity player, ChallengeConfig.Entry e) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        ChallengeConfig cfg = ChallengeConfig.get();
        if (cfg.announceInChat) {
            Text msg = Text.literal("[Blackjack] ").formatted(Formatting.GOLD)
                    .append(Text.literal(player.getName().getString()).formatted(Formatting.WHITE))
                    .append(Text.literal(" saco: ").formatted(Formatting.GRAY))
                    .append(Text.literal(e.name).formatted(Formatting.YELLOW, Formatting.BOLD))
                    .append(e.description.isEmpty() ? Text.empty() : Text.literal(" - " + e.description).formatted(Formatting.GRAY));
            server.getPlayerManager().broadcast(msg, false);
        }
        ServerCommandSource src = player.getCommandSource().withLevel(4).withSilent();
        for (String c : e.commands) {
            String cmd = c.startsWith("/") ? c.substring(1) : c;
            cmd = cmd.replace("%player%", player.getName().getString());
            try {
                server.getCommandManager().executeWithPrefix(src, cmd);
            } catch (Exception ex) {
                BlackjackMod.LOGGER.warn("Fallo el comando del reto '{}': {}", e.id, cmd, ex);
            }
        }
    }
}
