package com.blackjackchallenge.server;

import com.blackjackchallenge.game.ChallengeConfig;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Collection;

/**
 *  /blackjack                      -> una mano para ti
 *  /blackjack <jugadores>          -> una mano para cada jugador
 *  /blackjack <jugadores> <id>     -> fuerza un reto (ej: nutria, revil)
 *  /blackjack list | reload
 */
public final class BlackjackCommand {
    private BlackjackCommand() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("blackjack")
                .requires(s -> s.hasPermissionLevel(2))
                .executes(ctx -> run(ctx.getSource(), java.util.List.of(ctx.getSource().getPlayerOrThrow()), null))
                .then(CommandManager.literal("reload").executes(ctx -> {
                    ChallengeConfig.load();
                    ctx.getSource().sendFeedback(() -> Text.literal("Config recargada: " + ChallengeConfig.get().challenges.size() + " retos."), true);
                    return 1;
                }))
                .then(CommandManager.literal("list").executes(ctx -> {
                    StringBuilder sb = new StringBuilder("Retos: ");
                    for (ChallengeConfig.Entry e : ChallengeConfig.get().challenges)
                        sb.append(e.id).append("(").append(e.weight).append(") ");
                    String s = sb.toString();
                    ctx.getSource().sendFeedback(() -> Text.literal(s), false);
                    return 1;
                }))
                .then(CommandManager.argument("jugadores", EntityArgumentType.players())
                        .executes(ctx -> run(ctx.getSource(), EntityArgumentType.getPlayers(ctx, "jugadores"), null))
                        .then(CommandManager.argument("reto", StringArgumentType.word())
                                .suggests((ctx, b) -> {
                                    java.util.List<String> ids = new java.util.ArrayList<>();
                                    for (ChallengeConfig.Entry e : ChallengeConfig.get().challenges) ids.add(e.id);
                                    return CommandSource.suggestMatching(ids, b);
                                })
                                .executes(ctx -> run(ctx.getSource(), EntityArgumentType.getPlayers(ctx, "jugadores"),
                                        StringArgumentType.getString(ctx, "reto"))))));
    }

    private static int run(ServerCommandSource src, Collection<ServerPlayerEntity> targets, String id) {
        ChallengeConfig.Entry forced = null;
        if (id != null) {
            forced = ChallengeConfig.get().byId(id);
            if (forced == null) {
                src.sendError(Text.literal("No existe el reto '" + id + "'. Usa /blackjack list"));
                return 0;
            }
        }
        for (ServerPlayerEntity p : targets) PendingRuns.start(p, forced);
        return targets.size();
    }
}
