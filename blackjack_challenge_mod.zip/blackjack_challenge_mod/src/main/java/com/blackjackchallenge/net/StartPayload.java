package com.blackjackchallenge.net;

import com.blackjackchallenge.BlackjackMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> cliente: "anima esta mano" (el guion va serializado en un String). */
public record StartPayload(String data) implements CustomPayload {
    public static final CustomPayload.Id<StartPayload> ID = new CustomPayload.Id<>(Identifier.of(BlackjackMod.MOD_ID, "start"));
    public static final PacketCodec<RegistryByteBuf, StartPayload> CODEC =
            PacketCodecs.STRING.xmap(StartPayload::new, StartPayload::data).cast();

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}
