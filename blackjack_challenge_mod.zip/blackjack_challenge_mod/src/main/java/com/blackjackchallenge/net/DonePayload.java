package com.blackjackchallenge.net;

import com.blackjackchallenge.BlackjackMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Cliente -> servidor: "la animacion termino" (token de la mano). */
public record DonePayload(String token) implements CustomPayload {
    public static final CustomPayload.Id<DonePayload> ID = new CustomPayload.Id<>(Identifier.of(BlackjackMod.MOD_ID, "done"));
    public static final PacketCodec<RegistryByteBuf, DonePayload> CODEC =
            PacketCodecs.STRING.xmap(DonePayload::new, DonePayload::token).cast();

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}
