package com.blackjackchallenge.game;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Linea de tiempo PURA (sin clases de Minecraft) de una mano.
 * La usa el cliente para animar/sonar y el servidor para saber cuanto dura.
 * Todas las cartas se reparten UNA POR UNA, cada una con su viaje, su giro y su suspenso.
 */
public final class Timeline {
    public static final double ARRIVE = 0.50;     // viaje del zapato a la mesa
    public static final double FLIP = 0.32;       // duracion del giro
    public static final double SHUFFLE_START = 0.25, SHUFFLE_END = 1.95;

    public static final class Deal {
        public final boolean player; public final int index; public final int card;
        public final double tDeal; public double tFlip = -1; public final double hover;
        Deal(boolean player, int index, int card, double tDeal, double hover) {
            this.player = player; this.index = index; this.card = card; this.tDeal = tDeal; this.hover = hover;
        }
        public double tArrive() { return tDeal + ARRIVE; }
    }

    public record Cue(double t, String sound, float pitch, float vol) {}

    public final List<Deal> deals = new ArrayList<>();
    public final List<Cue> cues = new ArrayList<>();
    public double stampAt, bannerAt, bannerEnd;
    public double leaveStart = -1, leaveEnd = -1;      // solo especiales: la mesa se va
    public double specialStart = -1, specialEnd = -1;
    public double tensionStart = -1;
    public double total;
    public Deal holeCard;
    public final Script script;

    private void cue(double t, String s) { cues.add(new Cue(t, s, 1f, 1f)); }
    private void cue(double t, String s, float pitch, float vol) { cues.add(new Cue(t, s, pitch, vol)); }

    private Deal add(boolean player, int idx, int card, double tDeal, boolean faceUp, double hover) {
        Deal d = new Deal(player, idx, card, tDeal, hover);
        if (faceUp) d.tFlip = d.tArrive() + 0.10 + hover;
        deals.add(d);
        cue(tDeal, "deal", 0.95f + (idx % 3) * 0.05f, 0.9f);
        if (faceUp) cue(d.tFlip, "flip");
        return d;
    }

    public Timeline(Script s) {
        this.script = s;
        int[] P = s.player(), D = s.dealer();
        boolean special = s.kind() != Script.Kind.NORMAL;

        cue(0.12, "shuffle");
        cue(2.00, "thud", 1.2f, 0.5f);

        // ---- reparto inicial: J, B, J, B(oculta)
        double t = 2.25;
        add(true, 0, P[0], t, true, 0);           t += 0.55;
        add(false, 0, D[0], t, true, 0);          t += 0.55;
        add(true, 1, P[1], t, true, 0);           t += 0.55;
        holeCard = add(false, 1, D[1], t, false, 0);
        t += ARRIVE + 1.1;

        // ---- el jugador pide carta, de una en una
        Deal lastP = deals.get(2);
        for (int k = 2; k < P.length; k++) {
            boolean last = k == P.length - 1;
            double hover;
            if (s.kind() == Script.Kind.NUTRIA && last) hover = 1.7;
            else if (s.kind() == Script.Kind.REVIL && last) hover = 1.9;
            else if (s.kind() == Script.Kind.REVIL && k == 2) hover = 0.8;
            else hover = 0.25;
            if (s.kind() == Script.Kind.REVIL && k == 2) tensionStart = t;
            cue(t - 0.15, "chip", 1.4f, 0.35f);
            lastP = add(true, k, P[k], t, true, hover);
            cue(lastP.tFlip + 0.05, "tick", 1f, 0.6f);
            t = lastP.tFlip + FLIP + 1.0;
        }

        boolean early = s.verdict() == Script.Verdict.BUST || s.verdict() == Script.Verdict.TRIPLE7;
        double dealerStart;
        if (early) {
            stampAt = lastP.tFlip + FLIP + 0.1;
            dealerStart = stampAt + 1.5;
        } else {
            dealerStart = t;
        }
        // ---- la banca revela la carta oculta y juega
        holeCard.tFlip = dealerStart;
        cue(dealerStart, "flip", 0.9f, 1f);
        t = dealerStart + FLIP + 0.9;
        for (int k = 2; k < D.length; k++) {
            Deal d = add(false, k, D[k], t, true, 0.15);
            t = d.tFlip + FLIP + 0.9;
        }
        if (!early) stampAt = t - 0.3;
        double endBJ = Math.max(t, stampAt + 1.6);

        // ---- sonido del veredicto + fichas
        switch (s.verdict()) {
            case BLACKJACK, WIN, TRIPLE7 -> {
                cue(stampAt, "blackjack");
                for (int i = 0; i < 4; i++) cue(stampAt + 0.25 + 0.13 * i, "chip", 0.9f + i * 0.08f, 0.8f);
            }
            case LOSE, BUST -> {
                cue(stampAt, "bust");
                for (int i = 0; i < 3; i++) cue(stampAt + 0.7 + 0.12 * i, "chip", 0.7f, 0.6f);
            }
            case PUSH -> cue(stampAt, "result");
        }

        if (!special) {
            bannerAt = Math.max(stampAt + 1.7, endBJ);
            bannerEnd = bannerAt + 4.6;
            cue(bannerAt, "chip", 1.2f, 0.7f);
            total = bannerEnd + 0.9;
        } else {
            leaveStart = endBJ + 0.4;
            leaveEnd = leaveStart + 1.3;
            specialStart = leaveStart + 0.9;
            specialEnd = specialStart + s.specialSeconds();
            bannerAt = specialStart;
            bannerEnd = specialEnd;
            if (s.kind() == Script.Kind.NUTRIA) cue(specialStart, "nutria_music");
            else cue(specialStart, "revil_sting");
            total = specialEnd + 0.4;
        }
        cues.sort(Comparator.comparingDouble(Cue::t));
    }
}
