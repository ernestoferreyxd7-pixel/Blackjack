package com.blackjackchallenge.game;

/** Carta = suit*13 + rank. suit: 0=picas 1=corazones 2=diamantes 3=treboles. rank: 0=A, 1..8 = 2..9, 9=10, 10=J, 11=Q, 12=K */
public final class Cards {
    private Cards() {}

    public static int rank(int c) { return c % 13; }
    public static int suit(int c) { return c / 13; }

    /** Valor base (As = 11). */
    public static int value(int c) {
        int r = rank(c);
        if (r == 0) return 11;
        return Math.min(10, r + 1);
    }

    /** Mejor total <= 21 de las primeras {@code count} cartas. */
    public static int total(int[] cards, int count) {
        int sum = 0, aces = 0;
        for (int i = 0; i < count && i < cards.length; i++) {
            sum += value(cards[i]);
            if (rank(cards[i]) == 0) aces++;
        }
        while (sum > 21 && aces > 0) { sum -= 10; aces--; }
        return sum;
    }

    public static int total(int[] cards) { return total(cards, cards.length); }
}
