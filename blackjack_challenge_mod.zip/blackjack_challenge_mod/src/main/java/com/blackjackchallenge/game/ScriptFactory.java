package com.blackjackchallenge.game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/** Construye la mano de blackjack que "cae" en el reto elegido. */
public final class ScriptFactory {
    private ScriptFactory() {}

    public static Script create(ChallengeConfig.Entry e, ChallengeConfig cfg, Random r) {
        String token = UUID.randomUUID().toString();
        long seed = r.nextLong();
        return switch (e.kind()) {
            case NUTRIA -> nutria(token, e, cfg, r, seed);
            case REVIL -> revil(token, e, cfg, r, seed);
            default -> normal(token, e, cfg, r, seed);
        };
    }

    /** 7 - 7 - 7 = 21, uno por uno. */
    private static Script nutria(String token, ChallengeConfig.Entry e, ChallengeConfig cfg, Random r, long seed) {
        List<Integer> suits = new ArrayList<>(List.of(0, 1, 2, 3));
        Collections.shuffle(suits, r);
        int[] player = { suits.get(0) * 13 + 6, suits.get(1) * 13 + 6, suits.get(2) * 13 + 6 };
        int up = r.nextInt(4) * 13 + 9 + r.nextInt(4);        // 10, J, Q, K
        int hole = suits.get(3) * 13 + 7 + r.nextInt(2);       // 8 o 9 (nunca otro 7)
        return new Script(token, Script.Kind.NUTRIA, e.name, e.description, Script.Verdict.TRIPLE7,
                player, new int[] { up, hole }, cfg.nutriaSeconds, false, seed);
    }

    /** 6 - 6 - 6 - 6 = 24 -> te pasaste. La banca tiene blackjack. */
    private static Script revil(String token, ChallengeConfig.Entry e, ChallengeConfig cfg, Random r, long seed) {
        int[] player = { 0 * 13 + 5, 3 * 13 + 5, 1 * 13 + 5, 2 * 13 + 5 };
        int[] dealer = { 12, 0 };                              // K de picas + As de picas
        return new Script(token, Script.Kind.REVIL, e.name, e.description, Script.Verdict.BUST,
                player, dealer, cfg.revilSeconds, cfg.revilVignette, seed);
    }

    /** Mano normal y variada: nunca 7-7-7 ni la serie de seis que usan los especiales, nunca se pasa. */
    private static Script normal(String token, ChallengeConfig.Entry e, ChallengeConfig cfg, Random r, long seed) {
        for (int attempt = 0; attempt < 500; attempt++) {
            List<Integer> deck = new ArrayList<>();
            for (int i = 0; i < 52; i++) deck.add(i);
            Collections.shuffle(deck, r);
            int idx = 0;
            List<Integer> p = new ArrayList<>(), d = new ArrayList<>();
            p.add(deck.get(idx++)); d.add(deck.get(idx++)); p.add(deck.get(idx++)); d.add(deck.get(idx++));

            boolean natural = Cards.total(toArr(p)) == 21;
            if (!natural) {
                int target = 14 + r.nextInt(7);                // se planta entre 14 y 20
                while (Cards.total(toArr(p)) < target && p.size() < 7) p.add(deck.get(idx++));
            }
            int pt = Cards.total(toArr(p));
            if (pt > 21) continue;
            if (count(p, 6) >= 3 || count(p, 5) >= 3) continue;   // nada de 7-7-7 / 6-6-6 en retos normales
            if (!natural) while (Cards.total(toArr(d)) < 17 && d.size() < 7) d.add(deck.get(idx++));
            int dt = Cards.total(toArr(d));

            Script.Verdict v;
            if (natural) v = (dt == 21 && d.size() == 2) ? Script.Verdict.PUSH : Script.Verdict.BLACKJACK;
            else if (dt > 21 || pt > dt) v = Script.Verdict.WIN;
            else if (pt < dt) v = Script.Verdict.LOSE;
            else v = Script.Verdict.PUSH;
            return new Script(token, Script.Kind.NORMAL, e.name, e.description, v,
                    toArr(p), toArr(d), 0, false, seed);
        }
        // imposible en la practica, pero por si acaso:
        return new Script(token, Script.Kind.NORMAL, e.name, e.description, Script.Verdict.WIN,
                new int[] { 9, 13 + 7 }, new int[] { 26 + 9, 26 + 8 }, 0, false, seed);
    }

    private static int count(List<Integer> cards, int rank) {
        int n = 0; for (int c : cards) if (Cards.rank(c) == rank) n++; return n;
    }
    private static int[] toArr(List<Integer> l) { int[] a = new int[l.size()]; for (int i = 0; i < a.length; i++) a[i] = l.get(i); return a; }
}
