package com.blackjackchallenge.game;

import com.blackjackchallenge.BlackjackMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Config en config/blackjackchallenge.json — AQUI pones TUS retos (es la "ruleta"). */
public final class ChallengeConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static ChallengeConfig INSTANCE = new ChallengeConfig();

    public int nutriaSeconds = 11;          // duracion del baile del Momento Nutria (la musica dura ~11 s)
    public int revilSeconds = 24;           // duracion del Momento Revil (la tension suena TODO este tiempo)
    public boolean revilVignette = false;   // true = oscurece los bordes de la pantalla en el Momento Revil
    public boolean announceInChat = true;
    public List<Entry> challenges = new ArrayList<>();

    public static final class Entry {
        public String id = "reto";
        public String name = "Reto";
        public String description = "";
        public int weight = 10;
        public String type = "NORMAL";             // NORMAL | NUTRIA | REVIL
        public List<String> commands = new ArrayList<>();   // %player% = jugador

        public Script.Kind kind() {
            try { return Script.Kind.valueOf(type.toUpperCase()); } catch (Exception e) { return Script.Kind.NORMAL; }
        }
    }

    public static ChallengeConfig get() { return INSTANCE; }

    private static Entry e(String id, String name, String desc, int w, String type, String... cmds) {
        Entry x = new Entry(); x.id = id; x.name = name; x.description = desc; x.weight = w; x.type = type;
        x.commands = new ArrayList<>(List.of(cmds)); return x;
    }

    private static ChallengeConfig defaults() {
        ChallengeConfig c = new ChallengeConfig();
        c.challenges.add(e("nutria", "MOMENTO NUTRIA", "Ahora nadas como una nutria", 8, "NUTRIA",
                "effect give %player% minecraft:dolphins_grace 120 1",
                "effect give %player% minecraft:water_breathing 120 0",
                "effect give %player% minecraft:regeneration 20 1"));
        c.challenges.add(e("revil", "MOMENTO REVIL", "Algo viene por ti...", 8, "REVIL",
                "effect give %player% minecraft:darkness 25 0",
                "execute at %player% run summon minecraft:skeleton ~3 ~ ~3",
                "execute at %player% run summon minecraft:skeleton ~-3 ~ ~3",
                "execute at %player% run summon minecraft:skeleton ~ ~ ~-3"));
        c.challenges.add(e("lento", "Pies de plomo", "Lentitud durante 60 segundos", 10, "NORMAL",
                "effect give %player% minecraft:slowness 60 1"));
        c.challenges.add(e("ciego", "Ceguera", "No ves nada durante 20 segundos", 8, "NORMAL",
                "effect give %player% minecraft:blindness 20 0"));
        c.challenges.add(e("hambre", "Hambre canina", "Hambre durante 2 minutos", 10, "NORMAL",
                "effect give %player% minecraft:hunger 120 2"));
        c.challenges.add(e("salto", "Conejo loco", "Salto enorme durante 60 segundos", 9, "NORMAL",
                "effect give %player% minecraft:jump_boost 60 6"));
        c.challenges.add(e("levita", "Levitacion", "Subes por los aires 8 segundos", 7, "NORMAL",
                "effect give %player% minecraft:levitation 8 1"));
        c.challenges.add(e("brillo", "Faro humano", "Brillas 90 segundos: todos te ven", 9, "NORMAL",
                "effect give %player% minecraft:glowing 90 0"));
        c.challenges.add(e("dano", "Mala suerte", "Pierdes 5 corazones", 6, "NORMAL",
                "damage %player% 10 minecraft:generic"));
        c.challenges.add(e("pan", "Regalo de la casa", "La banca te regala 16 de pan", 10, "NORMAL",
                "give %player% minecraft:bread 16"));
        c.challenges.add(e("absorcion", "Escudo dorado", "Absorcion y resistencia 60 s", 8, "NORMAL",
                "effect give %player% minecraft:absorption 60 3",
                "effect give %player% minecraft:resistance 60 0"));
        c.challenges.add(e("tp", "Viaje sorpresa", "Te teletransportan lejos", 6, "NORMAL",
                "spreadplayers ~ ~ 50 300 false %player%"));
        c.challenges.add(e("creeper", "Visita inesperada", "Aparece un creeper cerca", 6, "NORMAL",
                "execute at %player% run summon minecraft:creeper ~4 ~ ~4"));
        return c;
    }

    public static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("blackjackchallenge.json"); }

    public static void load() {
        Path p = path();
        try {
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    ChallengeConfig c = GSON.fromJson(r, ChallengeConfig.class);
                    if (c != null && c.challenges != null && !c.challenges.isEmpty()) { INSTANCE = c; return; }
                }
            }
            INSTANCE = defaults();
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(p)) { GSON.toJson(INSTANCE, w); }
        } catch (IOException | RuntimeException ex) {
            BlackjackMod.LOGGER.error("No pude leer {} — uso los retos por defecto", p, ex);
            INSTANCE = defaults();
        }
    }

    public Entry byId(String id) {
        for (Entry e : challenges) if (e.id.equalsIgnoreCase(id)) return e;
        return null;
    }

    public Entry pick(Random r) {
        int total = 0;
        for (Entry e : challenges) total += Math.max(0, e.weight);
        if (total <= 0) return challenges.get(r.nextInt(challenges.size()));
        int n = r.nextInt(total);
        for (Entry e : challenges) { n -= Math.max(0, e.weight); if (n < 0) return e; }
        return challenges.get(0);
    }
}
