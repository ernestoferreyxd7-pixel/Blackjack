package com.blackjackchallenge.game;

/**
 * Guion completo de una mano. El servidor decide TODO (reto + cartas) y el cliente solo lo anima.
 * Asi el resultado es el mismo para todos y no depende del azar del cliente.
 */
public record Script(String token, Kind kind, String name, String desc, Verdict verdict,
                     int[] player, int[] dealer, int specialSeconds, boolean vignette, long seed) {

    public enum Kind { NORMAL, NUTRIA, REVIL }
    public enum Verdict { BLACKJACK, WIN, LOSE, PUSH, BUST, TRIPLE7 }

    private static final String SEP = "\u001F";

    private static String csv(int[] a) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(','); sb.append(a[i]); }
        return sb.toString();
    }

    private static int[] parse(String s) {
        if (s.isEmpty()) return new int[0];
        String[] p = s.split(",");
        int[] r = new int[p.length];
        for (int i = 0; i < p.length; i++) r[i] = Integer.parseInt(p[i].trim());
        return r;
    }

    private static String clean(String s) { return s == null ? "" : s.replace(SEP, " "); }

    public String encode() {
        return String.join(SEP, token, kind.name(), clean(name), clean(desc), verdict.name(),
                csv(player), csv(dealer), Integer.toString(specialSeconds), vignette ? "1" : "0", Long.toString(seed));
    }

    public static Script decode(String s) {
        String[] f = s.split(SEP, -1);
        return new Script(f[0], Kind.valueOf(f[1]), f[2], f[3], Verdict.valueOf(f[4]),
                parse(f[5]), parse(f[6]), Integer.parseInt(f[7]), f[8].equals("1"), Long.parseLong(f[9]));
    }
}
