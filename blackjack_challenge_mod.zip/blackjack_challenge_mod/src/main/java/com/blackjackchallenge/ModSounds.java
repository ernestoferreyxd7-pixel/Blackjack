package com.blackjackchallenge;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

public final class ModSounds {
    private static final Map<String, SoundEvent> MAP = new HashMap<>();
    public static SoundEvent NUTRIA_MUSIC, REVIL_TENSION;

    private static SoundEvent reg(String name) {
        Identifier id = Identifier.of(BlackjackMod.MOD_ID, name);
        SoundEvent ev = Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
        MAP.put(name, ev);
        return ev;
    }

    public static void init() {
        for (String n : new String[] { "shuffle", "deal", "flip", "chip", "blackjack", "bust", "result", "tick", "thud", "revil_sting" }) reg(n);
        NUTRIA_MUSIC = reg("nutria_music");
        REVIL_TENSION = reg("revil_tension");
    }

    public static SoundEvent byName(String n) { return MAP.get(n); }
}
