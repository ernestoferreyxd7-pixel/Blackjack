package com.blackjackchallenge.client;

import com.blackjackchallenge.ModSounds;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.random.Random;

import java.util.function.DoubleSupplier;

/**
 * Musica de tension en LOOP: no se corta sola. Solo termina cuando la animacion le dice (stop()).
 * Tiene su propia envolvente de volumen (sube con el tiempo y baja justo al final).
 */
public class TensionSound extends MovingSoundInstance {
    private final DoubleSupplier envelope;
    private boolean stopping;

    public TensionSound(DoubleSupplier envelope) {
        super(ModSounds.REVIL_TENSION, SoundCategory.MASTER, Random.create());
        this.envelope = envelope;
        this.repeat = true;
        this.repeatDelay = 0;
        this.relative = true;
        this.attenuationType = SoundInstance.AttenuationType.NONE;
        this.volume = 0.01f;
        this.pitch = 1.0f;
    }

    public void stop() { this.stopping = true; }

    @Override
    public void tick() {
        if (stopping) { setDone(); return; }
        float e = (float) Math.max(0.0, Math.min(1.0, envelope.getAsDouble()));
        this.volume = Math.max(0.01f, 0.35f + 0.65f * e);
        this.pitch = 1.0f + 0.05f * e;
    }
}
