package com.blackjackchallenge.client;

import com.blackjackchallenge.BlackjackMod;
import com.blackjackchallenge.game.Script;
import com.blackjackchallenge.net.StartPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class BlackjackClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(StartPayload.ID, (payload, context) -> {
            try {
                Script s = Script.decode(payload.data());
                context.client().execute(() -> Overlay.start(s));
            } catch (Exception e) {
                BlackjackMod.LOGGER.error("Guion de blackjack invalido", e);
            }
        });
        HudRenderCallback.EVENT.register(Overlay::render);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> Overlay.abort());
    }
}
