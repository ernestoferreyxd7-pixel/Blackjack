package com.blackjackchallenge.client;

import com.blackjackchallenge.BlackjackMod;
import com.blackjackchallenge.ModSounds;
import com.blackjackchallenge.game.Cards;
import com.blackjackchallenge.game.Script;
import com.blackjackchallenge.game.Timeline;
import com.blackjackchallenge.net.DonePayload;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.RotationAxis;

import java.util.List;

/**
 * Overlay (HUD) que anima el blackjack. No bloquea el juego: sigues pudiendo moverte.
 * Todo se dibuja como funcion del tiempo t (segundos desde el inicio), segun la {@link Timeline}.
 */
public final class Overlay {
    private Overlay() {}

    private static Session current;

    public static void start(Script s) {
        abort();
        current = new Session(s);
    }

    public static void abort() {
        if (current != null) { current.stopAllSounds(); current = null; }
    }

    public static void render(DrawContext ctx, RenderTickCounter tc) {
        Session s = current;
        if (s == null) return;
        try {
            s.render(ctx);
        } catch (Throwable t) {
            BlackjackMod.LOGGER.error("Error dibujando el blackjack; cancelo la animacion", t);
            s.finish();
        }
    }

    // ------------------------------------------------------------------ texturas
    private static Identifier tex(String n) { return Identifier.of(BlackjackMod.MOD_ID, "textures/gui/" + n + ".png"); }
    private static final Identifier TABLE = tex("table"), CARDS = tex("cards"), BACK = tex("card_back"),
            BACK_BLACK = tex("card_back_black"), CHIPS = tex("chips"), SHOE = tex("shoe"), GLOW = tex("glow"),
            CIRC = tex("skel_circle"), SOLO = tex("skel_solo");

    // sprite sheets (ver tools/build_sheets.py)
    private static final int CIRC_W = 376, CIRC_H = 268, CIRC_COLS = 8, CIRC_FRAMES = 64, CIRC_SW = 3008, CIRC_SH = 2144;
    private static final int SOLO_W = 210, SOLO_H = 355, SOLO_COLS = 9, SOLO_FRAMES = 54, SOLO_SW = 1890, SOLO_SH = 2130;
    // espacio de la mesa
    private static final int CARD_W = 96, CARD_H = 134;
    private static final float PLAYER_CY = 445 + CARD_H / 2f, DEALER_CY = 80 + CARD_H / 2f, SPACING = 64f;
    private static final float SHOE_X = 1095, SHOE_Y = 150;
    private static final float STACK_X = 250, STACK_Y = 520;

    // ------------------------------------------------------------------ utilidades
    private static float clamp01(double x) { return (float) Math.max(0.0, Math.min(1.0, x)); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float smooth(double x) { float t = clamp01(x); return t * t * (3 - 2 * t); }
    private static float easeOutCubic(double x) { float t = 1 - clamp01(x); return 1 - t * t * t; }
    private static float easeOutBack(double x) {
        float t = clamp01(x) - 1; float c1 = 1.70158f, c3 = c1 + 1;
        return 1 + c3 * t * t * t + c1 * t * t;
    }
    private static float hash(long a, int b) {
        long x = a * 0x9E3779B97F4A7C15L + b * 0xBF58476D1CE4E5B9L;
        x ^= x >>> 30; x *= 0xBF58476D1CE4E5B9L; x ^= x >>> 27; x *= 0x94D049BB133111EBL; x ^= x >>> 31;
        return (float) ((x >>> 11) * (1.0 / (1L << 53)));
    }
    private static int argb(float a, int rgb) { return (((int) (clamp01(a) * 255)) << 24) | (rgb & 0xFFFFFF); }

    // ================================================================== SESION
    private static final class Session {
        final Script script;
        final Timeline tl;
        final long startMs = Util.getMeasuringTimeMs();
        final boolean special;
        int cueIdx = 0;
        TensionSound tension;
        boolean finished;
        // por frame
        DrawContext c; TextRenderer tr; int sw, sh; double t;

        Session(Script s) {
            this.script = s;
            this.tl = new Timeline(s);
            this.special = s.kind() != Script.Kind.NORMAL;
        }

        // -------------------------------------------------------------- sonido
        void play(String name, float pitch, float vol) {
            SoundEvent ev = ModSounds.byName(name);
            if (ev != null) MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ev, pitch, vol));
        }

        void startTension() {
            tension = new TensionSound(() -> {
                double rel = (Util.getMeasuringTimeMs() - startMs) / 1000.0;
                double ramp = Math.min(1.0, Math.max(0.0, (rel - tl.tensionStart) / Math.max(1.0, (tl.total - tl.tensionStart) * 0.8)));
                double fade = Math.min(1.0, Math.max(0.0, (tl.total - 0.3 - rel) / 0.8));
                return ramp * fade;
            });
            MinecraftClient.getInstance().getSoundManager().play(tension);
        }

        void stopAllSounds() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (tension != null) { tension.stop(); mc.getSoundManager().stop(tension); tension = null; }
            if (ModSounds.NUTRIA_MUSIC != null) mc.getSoundManager().stopSounds(ModSounds.NUTRIA_MUSIC.getId(), SoundCategory.MASTER);
        }

        void finish() {
            if (finished) return;
            finished = true;
            stopAllSounds();
            try { ClientPlayNetworking.send(new DonePayload(script.token())); } catch (Exception ignored) {}
            if (current == this) current = null;
        }

        // -------------------------------------------------------------- frame
        void render(DrawContext ctx) {
            t = (Util.getMeasuringTimeMs() - startMs) / 1000.0;
            List<Timeline.Cue> cues = tl.cues;
            while (cueIdx < cues.size() && cues.get(cueIdx).t() <= t) {
                Timeline.Cue q = cues.get(cueIdx++);
                if (t - q.t() < 1.5) play(q.sound(), q.pitch(), q.vol());
            }
            if (tl.tensionStart >= 0 && tension == null && t >= tl.tensionStart) startTension();
            if (t >= tl.total) { finish(); return; }

            c = ctx;
            MinecraftClient mc = MinecraftClient.getInstance();
            tr = mc.textRenderer;
            sw = ctx.getScaledWindowWidth();
            sh = ctx.getScaledWindowHeight();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            drawTablePhase();
            if (special && t >= tl.specialStart) {
                if (script.kind() == Script.Kind.NUTRIA) drawNutria(); else drawRevil();
                drawSpecialTitle();
            } else if (!special && t >= tl.bannerAt) {
                drawRibbon();
            }
            ctx.setShaderColor(1f, 1f, 1f, 1f);
        }

        // ============================================================ helpers de dibujo
        void col(float r, float g, float b, float a) { c.setShaderColor(r, g, b, a); }

        void text(String s, float cx, float cy, float scale, int rgb, float alpha, boolean shadow) {
            if (alpha < 0.03f) return;
            col(1, 1, 1, 1);
            MatrixStack m = c.getMatrices();
            m.push(); m.translate(cx, cy, 0); m.scale(scale, scale, 1);
            Text tx = Text.literal(s).formatted(Formatting.BOLD);
            int w = tr.getWidth(tx);
            c.drawText(tr, tx, -w / 2, -4, argb(alpha, rgb), shadow);
            m.pop();
        }

        void outlined(String s, float cx, float cy, float scale, int rgb, float alpha, int outline) {
            float o = Math.max(1f, scale * 0.5f);
            for (int dx = -1; dx <= 1; dx += 2) for (int dy = -1; dy <= 1; dy += 2)
                text(s, cx + dx * o, cy + dy * o, scale, outline, alpha, false);
            text(s, cx, cy, scale, rgb, alpha, false);
        }

        void fill(int x1, int y1, int x2, int y2, float a, int rgb) {
            if (a < 0.01f) return;
            col(1, 1, 1, 1);
            c.fill(x1, y1, x2, y2, argb(a, rgb));
        }

        // ============================================================ MESA
        void drawTablePhase() {
            float appear = clamp01(t / 0.6);
            float alpha, leave = 0;
            if (special) {
                leave = clamp01((t - tl.leaveStart) / (tl.leaveEnd - tl.leaveStart));
                alpha = appear * (1 - smooth(leave));
            } else {
                alpha = Math.min(appear, clamp01((tl.total - t) / 0.9));
            }
            if (alpha < 0.01f) return;
            float pop = 0.65f + 0.35f * easeOutBack(appear);
            float tableW = Math.min(sw * 0.84f, sh * 0.84f * 1280f / 720f);
            float s = tableW / 1280f;
            float dropY = leave * leave * sh * 0.30f;

            MatrixStack m = c.getMatrices();
            m.push();
            m.translate(sw / 2f, sh / 2f + dropY, 0);
            if (leave > 0) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(leave * leave * 9f));
            m.scale(s * pop, s * pop, 1);
            m.translate(-640, -360, 0);

            col(1, 1, 1, alpha);
            c.drawTexture(TABLE, 0, 0, 1280, 720, 0, 0, 1280, 720, 1280, 720);
            c.drawTexture(SHOE, 980, 70, 256, 170, 0, 0, 256, 170, 256, 170);

            drawChips(alpha);
            drawCards(alpha);
            drawBadges(alpha);
            drawStamp(alpha);
            m.pop();
            col(1, 1, 1, 1);
        }

        // ------------------------------------------------------------ cartas
        float nEff(boolean player) {
            float n = 0;
            for (Timeline.Deal d : tl.deals) if (d.player == player) n += smooth((t - d.tDeal) / 0.45);
            return n;
        }

        void drawCards(float alpha) {
            float nP = nEff(true), nD = nEff(false);
            for (Timeline.Deal d : tl.deals) {
                if (t < d.tDeal) continue;
                float n = d.player ? nP : nD;
                float tx = 640 + (d.index - (n - 1) / 2f) * SPACING;
                float ty = d.player ? PLAYER_CY : DEALER_CY;
                float tilt = (hash(script.seed(), d.index * 2 + (d.player ? 1 : 0)) - 0.5f) * 5f;
                float p = clamp01((t - d.tDeal) / Timeline.ARRIVE);
                float e = easeOutCubic(p);
                float x = lerp(SHOE_X, tx, e), y = lerp(SHOE_Y, ty, e) - (float) Math.sin(Math.PI * p) * 70f;
                float rot = lerp(32f, tilt, e);
                float scale = lerp(0.85f, 1f, e);
                float f = d.tFlip >= 0 ? clamp01((t - d.tFlip) / Timeline.FLIP) : 0f;

                // suspenso: la carta tiembla y brilla antes de girar
                boolean hover = d.hover > 0.5 && t >= d.tArrive() && t < d.tFlip + 0.45;
                if (hover) {
                    float k = t < d.tFlip ? clamp01((t - d.tArrive()) / d.hover) : 0f;
                    float burst = t >= d.tFlip ? clamp01(1 - (t - d.tFlip) / 0.45) : 0f;
                    x += (float) Math.sin(t * 70) * 2.2f * k;
                    y += (float) Math.cos(t * 83) * 1.6f * k;
                    float gs = 220f + 160f * burst + 40f * k;
                    float ga = alpha * (0.25f + 0.45f * k + 0.5f * burst);
                    float[] gc = glowColor();
                    col(gc[0], gc[1], gc[2], Math.min(1f, ga));
                    c.getMatrices().push();
                    c.getMatrices().translate(x, y, 0);
                    c.drawTexture(GLOW, (int) (-gs / 2), (int) (-gs / 2), (int) gs, (int) gs, 0, 0, 128, 128, 128, 128);
                    c.getMatrices().pop();
                }
                drawCard(d.card, x, y, rot, scale, f, alpha);
            }
        }

        float[] glowColor() {
            return switch (script.kind()) {
                case NUTRIA -> new float[] { 1f, 0.85f, 0.2f };
                case REVIL -> new float[] { 1f, 0.1f, 0.1f };
                default -> new float[] { 1f, 1f, 0.8f };
            };
        }

        void drawCard(int card, float cx, float cy, float rot, float scale, float flip, float alpha) {
            MatrixStack m = c.getMatrices();
            m.push();
            m.translate(cx, cy, 0);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rot));
            float lift = 1f + 0.18f * (float) Math.sin(Math.PI * flip);
            float sx = Math.max(0.03f, (float) Math.abs(Math.cos(Math.PI * flip)));
            m.scale(scale * lift * sx, scale * lift, 1);
            // sombra
            col(0, 0, 0, 0.35f * alpha);
            c.drawTexture(BACK, -CARD_W / 2 + 3, -CARD_H / 2 + 5, CARD_W, CARD_H, 0, 0, 160, 224, 160, 224);
            boolean face = flip >= 0.5f;
            float shade = face ? 1f : 1f - 0.25f * (float) Math.sin(Math.PI * flip);
            col(shade, shade, shade, alpha);
            if (face) {
                c.drawTexture(CARDS, -CARD_W / 2, -CARD_H / 2, CARD_W, CARD_H,
                        Cards.rank(card) * 160f, Cards.suit(card) * 224f, 160, 224, 2080, 896);
            } else {
                c.drawTexture(script.kind() == Script.Kind.REVIL ? BACK_BLACK : BACK, -CARD_W / 2, -CARD_H / 2, CARD_W, CARD_H, 0, 0, 160, 224, 160, 224);
            }
            m.pop();
        }

        // ------------------------------------------------------------ fichas
        void chip(int colorIdx, float x, float y, float alpha, float size) {
            col(1, 1, 1, alpha);
            c.drawTexture(CHIPS, (int) (x - size / 2), (int) (y - size / 2), (int) size, (int) size, colorIdx * 96f, 0, 96, 96, 480, 96);
        }

        void drawChips(float alpha) {
            Script.Verdict v = script.verdict();
            boolean win = v == Script.Verdict.BLACKJACK || v == Script.Verdict.WIN || v == Script.Verdict.TRIPLE7;
            boolean lose = v == Script.Verdict.LOSE || v == Script.Verdict.BUST;
            for (int i = 0; i < 4; i++) {
                float x = STACK_X, y = STACK_Y - i * 9;
                float a = alpha;
                if (lose && t >= tl.stampAt + 0.7 + 0.12 * i) {
                    float p = clamp01((t - (tl.stampAt + 0.7 + 0.12 * i)) / 0.55);
                    float e = easeOutCubic(p);
                    x = lerp(x, 640, e); y = lerp(y, DEALER_CY, e) - (float) Math.sin(Math.PI * p) * 50f;
                    a = alpha * (1f - smooth((p - 0.8) / 0.2));
                }
                chip(i % 4, x, y, a, 60);
            }
            if (win) {
                for (int j = 0; j < 4; j++) {
                    double t0 = tl.stampAt + 0.25 + 0.13 * j;
                    if (t < t0) continue;
                    float p = clamp01((t - t0) / 0.5);
                    float e = easeOutCubic(p);
                    float ty = STACK_Y - (4 + j) * 9;
                    chip((j + 1) % 5, lerp(640, STACK_X, e), lerp(DEALER_CY, ty, e) - (float) Math.sin(Math.PI * p) * 60f, alpha, 60);
                }
            }
        }

        // ------------------------------------------------------------ totales
        void drawBadges(float alpha) {
            int[] P = script.player(), D = script.dealer();
            int shownP = 0, shownD = 0; double lastP = -9, lastD = -9;
            for (Timeline.Deal d : tl.deals) {
                if (d.tFlip >= 0 && t >= d.tFlip + Timeline.FLIP * 0.5) {
                    if (d.player) { shownP++; lastP = d.tFlip; } else { shownD++; lastD = d.tFlip; }
                }
            }
            if (shownP > 0) {
                int tot = Cards.total(P, shownP);
                boolean nat = shownP == 2 && tot == 21;
                int rgb = tot > 21 ? 0xFF4A4A : tot == 21 ? 0x5CFF7A : 0xFFFFFF;
                badge(nat ? "BLACKJACK" : "JUGADOR", Integer.toString(tot), 1030, 520, rgb,
                        1f + 0.35f * clamp01(1 - (t - lastP) / 0.35), alpha);
            }
            if (shownD > 0) {
                boolean holeShown = tl.holeCard.tFlip >= 0 && t >= tl.holeCard.tFlip + Timeline.FLIP * 0.5;
                String val;
                int rgb = 0xFFFFFF;
                if (!holeShown) val = Cards.value(D[0]) + "+?";
                else { int tot = Cards.total(D, shownD); val = Integer.toString(tot); if (tot > 21) rgb = 0xFF4A4A; }
                badge("BANCA", val, 250, 150, rgb, 1f + 0.35f * clamp01(1 - (t - lastD) / 0.35), alpha);
            }
        }

        void badge(String label, String value, float cx, float cy, int rgb, float pop, float alpha) {
            MatrixStack m = c.getMatrices();
            m.push(); m.translate(cx, cy, 0); m.scale(pop, pop, 1);
            fill(-76, -44, 76, 44, 0.78f * alpha, 0x000000);
            fill(-76, -44, 76, -41, alpha, 0xD6AA46); fill(-76, 41, 76, 44, alpha, 0xD6AA46);
            fill(-76, -44, -73, 44, alpha, 0xD6AA46); fill(73, -44, 76, 44, alpha, 0xD6AA46);
            text(label, 0, -27, 2.1f, 0xE8D8A0, alpha, false);
            text(value, 0, 12, 5.2f, rgb, alpha, true);
            m.pop();
        }

        // ------------------------------------------------------------ sello del veredicto
        void drawStamp(float alpha) {
            if (t < tl.stampAt) return;
            float a = alpha;
            if (!special) a *= 1f - smooth((t - tl.bannerAt) / 0.3);
            if (a < 0.02f) return;
            String s; int rgb;
            switch (script.verdict()) {
                case BLACKJACK -> { s = "¡BLACKJACK!"; rgb = 0xFFD84A; }
                case WIN -> { s = "¡GANASTE!"; rgb = 0x5CFF7A; }
                case LOSE -> { s = "PIERDES"; rgb = 0xFF5050; }
                case PUSH -> { s = "EMPATE"; rgb = 0xFFFFFF; }
                case BUST -> { s = "¡TE PASASTE!"; rgb = 0xFF2A2A; }
                default -> { s = "¡7 - 7 - 7!"; rgb = 0xFFD84A; }
            }
            float p = clamp01((t - tl.stampAt) / 0.45);
            float sc = lerp(3.4f, 1f, easeOutCubic(p)) * (1f + 0.04f * (float) Math.sin(t * 8));
            MatrixStack m = c.getMatrices();
            m.push(); m.translate(640, 300, 0);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-7f));
            fill(-520, -52, 520, 52, 0.62f * a * p, 0x000000);
            fill(-520, -52, 520, -49, a * p, rgb); fill(-520, 49, 520, 52, a * p, rgb);
            m.scale(sc, sc, 1);
            outlined(s, 0, 4, 9f, rgb, a * p, 0x000000);
            m.pop();
        }

        // ============================================================ CINTA DEL RETO (retos normales)
        void drawRibbon() {
            float p = (float) ((t - tl.bannerAt) / 0.6);
            float e = easeOutBack(p);
            float a = Math.min(clamp01((t - tl.bannerAt) / 0.2), clamp01((tl.total - t) / 0.9));
            if (a < 0.02f) return;
            int bandH = Math.max(64, (int) (sh * 0.22f));
            MatrixStack m = c.getMatrices();
            m.push(); m.translate(sw / 2f, sh / 2f, 0); m.scale(Math.max(0.001f, e), 1, 1);
            fill(-sw, -bandH / 2, sw, bandH / 2, 0.82f * a, 0x0A0A0F);
            fill(-sw, -bandH / 2, sw, -bandH / 2 + 3, a, 0xD6AA46); fill(-sw, bandH / 2 - 3, sw, bandH / 2, a, 0xD6AA46);
            float u = bandH / 64f;
            text("R E T O", 0, -bandH * 0.30f, 1.3f * u, 0xD6AA46, a, true);
            // nombre autoajustado al ancho
            int w = tr.getWidth(Text.literal(script.name()).formatted(Formatting.BOLD));
            float sc = Math.min(3.2f * u, sw * 0.86f / Math.max(1, w));
            outlined(script.name(), 0, bandH * 0.06f, sc, 0xFFFFFF, a, 0x000000);
            if (!script.desc().isEmpty()) {
                int dw = tr.getWidth(Text.literal(script.desc()).formatted(Formatting.BOLD));
                float ds = Math.min(1.35f * u, sw * 0.86f / Math.max(1, dw));
                text(script.desc(), 0, bandH * 0.34f, ds, 0xC8C8D0, a, true);
            }
            m.pop();
            col(1, 1, 1, 1);
        }

        // ============================================================ MOMENTO NUTRIA
        void drawNutria() {
            double rel = t - tl.specialStart;
            float appear = easeOutBack(rel / 0.7);
            float a = Math.min(clamp01(rel / 0.4), clamp01((tl.specialEnd - t) / 0.8));
            int frame = (int) Math.floor(rel * 30) % SOLO_FRAMES;
            double beat = 60.0 / 126.0;
            float bob = (float) Math.abs(Math.sin(Math.PI * rel / beat)) * sh * 0.022f;
            float sway = 4f * (float) Math.sin(2 * Math.PI * rel / (beat * 2));
            float h = sh * 0.68f;
            float k = h / SOLO_H * Math.max(0.001f, appear);
            int u = (frame % SOLO_COLS) * SOLO_W, v = (frame / SOLO_COLS) * SOLO_H;

            MatrixStack m = c.getMatrices();
            m.push();
            m.translate(sw / 2f, sh * 0.54f - bob, 0);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sway));
            m.scale(k, k, 1);
            // sombra (para que se vea sobre cielos claros)
            col(0, 0, 0, 0.55f * a);
            c.drawTexture(SOLO, -SOLO_W / 2 + 4, -SOLO_H / 2 + 6, SOLO_W, SOLO_H, u, v, SOLO_W, SOLO_H, SOLO_SW, SOLO_SH);
            col(1, 1, 1, a);
            c.drawTexture(SOLO, -SOLO_W / 2, -SOLO_H / 2, SOLO_W, SOLO_H, u, v, SOLO_W, SOLO_H, SOLO_SW, SOLO_SH);
            m.pop();
            col(1, 1, 1, 1);
        }

        // ============================================================ MOMENTO REVIL
        void drawCircle(int frame, float cx, float cy, float wpx, float r, float g, float b, float a, float glitch, long gs) {
            if (a < 0.01f) return;
            frame = Math.floorMod(frame, CIRC_FRAMES);
            float sc = wpx / CIRC_W;
            MatrixStack m = c.getMatrices();
            m.push(); m.translate(cx, cy, 0); m.scale(sc, sc, 1);
            int u0 = (frame % CIRC_COLS) * CIRC_W, v0 = (frame / CIRC_COLS) * CIRC_H;
            col(r, g, b, a);
            if (glitch < 0.02f) {
                c.drawTexture(CIRC, -CIRC_W / 2, -CIRC_H / 2, CIRC_W, CIRC_H, u0, v0, CIRC_W, CIRC_H, CIRC_SW, CIRC_SH);
            } else {
                int n = 12;                      // tiras horizontales desplazadas = glitch
                for (int j = 0; j < n; j++) {
                    int y0 = Math.round(j * (float) CIRC_H / n), y1 = Math.round((j + 1) * (float) CIRC_H / n);
                    int off = hash(gs, j) > 0.55f ? (int) ((hash(gs, j + 99) - 0.5f) * 2f * glitch * CIRC_W * 0.20f) : 0;
                    c.drawTexture(CIRC, -CIRC_W / 2 + off, -CIRC_H / 2 + y0, CIRC_W, y1 - y0, u0, v0 + y0, CIRC_W, y1 - y0, CIRC_SW, CIRC_SH);
                }
            }
            m.pop();
        }

        static final float[][] CROWD = {   // dx, dy (fraccion de pantalla), escala, alpha, desfase de frames, aparece en I>=
                { -0.34f, -0.03f, 0.55f, 0.50f, 17, 0.30f }, { 0.34f, -0.03f, 0.55f, 0.50f, 29, 0.30f },
                { -0.30f, 0.30f, 0.42f, 0.42f, 5, 0.55f }, { 0.30f, 0.30f, 0.42f, 0.42f, 41, 0.55f },
                { -0.12f, -0.36f, 0.38f, 0.36f, 11, 0.75f }, { 0.12f, 0.38f, 0.48f, 0.40f, 23, 0.80f } };

        void drawRevil() {
            double rel = t - tl.specialStart, dur = tl.specialEnd - tl.specialStart;
            float I = clamp01(rel / (dur * 0.85));                          // intensidad: sube todo el rato
            float A = Math.min(clamp01(rel / 1.2), clamp01((tl.specialEnd - t) / 1.0));
            long seed = script.seed();
            int win8 = (int) Math.floor(rel * 8), win10 = (int) Math.floor(rel * 10), win14 = (int) Math.floor(rel * 14);

            // tiempo "enfermo": se congela / se acelera a ratos
            double warped = rel + 0.35 * I * Math.sin(rel * 1.7);
            if (hash(seed, win8) < 0.08 + 0.22 * I) warped = win8 / 8.0;
            int frame = (int) Math.floor(warped * 20);

            // latido: pulso rojo sincronizado con el corazon de la musica (0.8 s)
            float pulse = (float) Math.max(0, 1 - ((rel % 0.8) / 0.22));
            float redMix = Math.min(1f, 0.25f * I + 0.75f * pulse * I);
            float r = lerp(0.84f, 1f, redMix), g = lerp(0.84f, 0.08f, redMix), b = lerp(0.88f, 0.08f, redMix);

            boolean blackout = hash(seed + 7, win14) < 0.03 + 0.10 * I * I;  // parpadeos de "se fue la luz"
            float jt = clamp01((rel - (dur - 4.0)) / 3.0);                   // el susto final: se acercan
            float zoom = 1f + 0.18f * I + 0.95f * jt * jt;
            float shake = 1.5f + 10f * I + 16f * jt;
            long fs = (long) Math.floor(rel * 24);
            float dx = (hash(fs, 1) - 0.5f) * 2f * shake, dy = (hash(fs, 2) - 0.5f) * 2f * shake;
            float baseW = Math.min(sw * 0.80f, sh * 1.05f * CIRC_W / CIRC_H);
            float cx = sw / 2f, cy = sh * 0.5f;

            // vineta opcional (desactivada por defecto: solo esqueletos)
            if (script.vignette()) {
                int edge = argb(0.55f * I * A, 0x300000);
                c.fillGradient(0, 0, sw, sh / 4, edge, 0);
                c.fillGradient(0, sh * 3 / 4, sw, sh, 0, edge);
            }

            // multitud: mas esqueletos van apareciendo conforme sube la intensidad
            for (float[] q : CROWD) {
                float vis = smooth((I - q[5]) / 0.15f);
                if (vis <= 0.01f || blackout) continue;
                float jx = (hash(fs + (long) q[4], 5) - 0.5f) * shake;
                drawCircle(frame + (int) q[4], cx + q[0] * sw + jx, cy + q[1] * sh, baseW * q[2] * zoom * 0.9f,
                        0.55f, 0.06f, 0.06f, q[3] * vis * A, 0.4f * I, seed + (long) q[4]);
            }
            if (!blackout) {
                // estelas: copias fantasma rojas que se arrastran detras (vision doble)
                for (int k = 3; k >= 1; k--) {
                    drawCircle(frame - k * 4, cx + dx * (1 + k * 0.5f), cy + dy, baseW * zoom * (1f + 0.035f * k * I),
                            0.7f, 0.0f, 0.0f, (0.10f + 0.30f * I) / k * A, 0f, seed);
                }
                float glitch = hash(seed + 3, win10) < 0.25 + 0.5 * I ? I * 0.9f + 0.1f : 0f;
                drawCircle(frame, cx + dx, cy + dy, baseW * zoom, r, g, b, A, glitch, seed + win10);
            }
            col(1, 1, 1, 1);
        }

        // ============================================================ TITULO de los momentos especiales
        void drawSpecialTitle() {
            double rel = t - tl.specialStart;
            float a = Math.min(clamp01((rel - 0.15) / 0.4), clamp01((tl.specialEnd - t) / 0.8));
            if (a < 0.02f) return;
            boolean nutria = script.kind() == Script.Kind.NUTRIA;
            String title = script.name();
            float pop = easeOutBack((rel - 0.15) / 0.5);
            int w = tr.getWidth(Text.literal(title).formatted(Formatting.BOLD));
            float sc = Math.min(5.5f, sw * 0.8f / Math.max(1, w)) * Math.max(0.001f, pop);
            float y = sh * 0.10f;
            if (nutria) {
                // letras que bailan al ritmo
                float total = w * sc, x = sw / 2f - total / 2f;
                int rgb = 0xFFD84A;
                for (int i = 0; i < title.length(); i++) {
                    String ch = String.valueOf(title.charAt(i));
                    float cw = tr.getWidth(Text.literal(ch).formatted(Formatting.BOLD)) * sc;
                    float off = (float) Math.sin(rel * 9 + i * 0.7) * sc * 2.2f;
                    int col = (i % 2 == 0) ? 0xFFD84A : 0xFFFFFF;
                    outlined(ch, x + cw / 2f, y + off, sc, col, a, 0x000000);
                    x += cw;
                }
            } else {
                long fs = (long) Math.floor(rel * 18);
                float I = clamp01(rel / ((tl.specialEnd - tl.specialStart) * 0.85));
                String shown = title;
                if (hash(script.seed(), (int) fs) < 0.10 * I + 0.03) {         // letras corruptas
                    StringBuilder sb = new StringBuilder(title);
                    int k = (int) (hash(script.seed() + 1, (int) fs) * title.length());
                    if (k < sb.length() && sb.charAt(k) != ' ') sb.setCharAt(k, "#@%&0$?!".charAt((int) (hash(script.seed() + 2, (int) fs) * 8) % 8));
                    shown = sb.toString();
                }
                float jx = (hash(fs, 11) - 0.5f) * 8f * I, jy = (hash(fs, 12) - 0.5f) * 5f * I;
                text(shown, sw / 2f - 4 + jx, y + jy, sc, 0x7A0000, a * 0.9f, false);
                text(shown, sw / 2f + 4 - jx, y + 2 - jy, sc, 0xFF1010, a * 0.8f, false);
                outlined(shown, sw / 2f, y, sc, 0xFFE8E8, a, 0x000000);
            }
            if (!script.desc().isEmpty()) {
                int dw = tr.getWidth(Text.literal(script.desc()).formatted(Formatting.BOLD));
                float ds = Math.min(2.2f, sw * 0.7f / Math.max(1, dw));
                text(script.desc(), sw / 2f, y + 10 * sc + 6, ds, nutria ? 0xFFF2B0 : 0xFF8080, a * 0.9f, true);
            }
            col(1, 1, 1, 1);
        }
    }
}
