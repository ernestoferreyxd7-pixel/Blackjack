package com.blackjackchallenge;

import com.blackjackchallenge.game.ChallengeConfig;
import com.blackjackchallenge.net.DonePayload;
import com.blackjackchallenge.net.StartPayload;
import com.blackjackchallenge.server.BlackjackCommand;
import com.blackjackchallenge.server.PendingRuns;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BlackjackMod implements ModInitializer {
    public static final String MOD_ID = "blackjackchallenge";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ChallengeConfig.load();
        ModSounds.init();

        PayloadTypeRegistry.playS2C().register(StartPayload.ID, StartPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(DonePayload.ID, DonePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(DonePayload.ID,
                (payload, context) -> PendingRuns.complete(context.player(), payload.token()));

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> BlackjackCommand.register(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(PendingRuns::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> PendingRuns.forget(handler.getPlayer().getUuid()));

        LOGGER.info("Blackjack Challenge listo. Usa /blackjack");
    }
}
